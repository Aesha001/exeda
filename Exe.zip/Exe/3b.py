def binning_smoothing_boundary(data, num_bins):
    min_val = min(data)
    max_val = max(data)
    bin_width = (max_val - min_val) / num_bins
    bins = [[] for _ in range(num_bins)]

    for value in data:
        bin_index = int((value - min_val) // bin_width)
        if bin_index == num_bins:
            bin_index -= 1
        bins[bin_index].append(value)

    smoothed_data = []
    for bin_values in bins:
        if bin_values:
            bin_boundary = [bin_values[0], bin_values[-1]][bin_values[0] - min_val > max_val - bin_values[-1]]
            smoothed_data.extend([bin_boundary] * len(bin_values))

    return smoothed_data

# Example usage for bin smoothing by boundary
data = [1, 2, 3, 7, 8, 9, 12, 15, 18, 20]
num_bins = 3
smoothed_by_boundary = binning_smoothing_boundary(data, num_bins)
print("Smoothed Data by Boundary:", smoothed_by_boundary)
