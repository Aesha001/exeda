
# data = [1, 2, 4, 5, 7, 9, 10, 12, 15, 18, 20]

data = []
n = int(input("Enter the list size "))

print("\n")
for i in range(0, n):
    print("Enter number at index", i, )
    item = int(input())
    data.append(item)
print("User list is ", data)

bin_boundaries = [0, 5, 10, 15, 20]

binned_data = []

for value in data:
    for i in range(len(bin_boundaries) - 1):
        if bin_boundaries[i] <= value < bin_boundaries[i + 1]:
            binned_data.append((value, i + 1))
            break
    else:
        pass

for value, bin_num in binned_data:
    print(f"{value} belongs to bin {bin_num}")


results = [0] * len(bin_boundaries)
for _, bin_num in binned_data:
    results[bin_num - 1] += 1

print("\nResults:")
for bin_num, count in enumerate(results):
    print(f"Bin {bin_num + 1}: {count} occurrences")
