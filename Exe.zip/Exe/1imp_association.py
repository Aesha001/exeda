tran=[['tea','milk'],['bread','butter','cheese'],['cheese','chocolate','cake'],['milk','bread','tea'],['tea','cofee','butter']]
# n=int(input("Enter number for nestedlist : "))
# lt=[]
# lt2=[]
# for i in range(n):
#     n1=int(input("Enter number of element you want in particular list : "))
#     for j in range(n1):
#         n2=input("Enter name/value ")
#         lt2.append(n2)
#     lt.append(lt2)
#     lt2=[]
# print(lt)
item=[] #tea,milk
for i in tran: #tea,milk
    for j in i: #tea
        if(j not in item):
            item.append(j) #tea,milk,bread...
print(item)

ct=0
te=[]
for i in item: #tea
    for j in tran: #[tea,milk]
        for k in j: #tea
            if(k==i):
                ct=ct+1
    te.append(ct)
    ct=0
print(te)

i=0
c2=[]
while(i<len(item)):
    if(te[i]>1):
        c2.append(item[i])
    i=i+1
print(c2)

i=0
temp=[]
j=0
c3=[]
while (i<len(c2)):
    j=i+1
    while(j<len(c2)):
        #temp=c2[i]+" "+c2[j]
        temp.append(c2[i])
        temp.append(c2[j])
        j=j+1
        c3.append(temp)
        temp=[]
    i=i+1
print(c3)

ct=0
l3=[]
for i in c3:
    i1=i[0]
    i2=i[1]
    for j in tran:
        if((i1 in j)and(i2 in j)):
            ct=ct+1
    l3.append(ct)
    ct=0
print(l3)

i=0
fc3=[]
while(i<len(c3)):
    if(l3[i]>1):
        fc3.append(c3[i])
    i=i+1
print(fc3)
            

            
    
        
            
    
