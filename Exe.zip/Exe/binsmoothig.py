def binning_smoothing(data, num_bins):
    # Calculate bin width
    min_val = min(data)
    max_val = max(data)
    bin_width = (max_val - min_val) / num_bins
    
    # Initialize bins
    bins = [[] for _ in range(num_bins)]
    
    # Assign data points to bins
    for value in data:
        bin_index = int((value - min_val) // bin_width)
        # Handle the case where value is equal to the max_val
        if bin_index == num_bins:
            bin_index -= 1
        bins[bin_index].append(value)
    
    # Smooth the data within each bin (using mean value in this case)
    smoothed_data = []
    for bin_values in bins:
        if bin_values:
            bin_mean = sum(bin_values) / len(bin_values)
            smoothed_data.extend([bin_mean] * len(bin_values))
    
    return smoothed_data

# Example usage
data = [1, 2, 3, 7, 8, 9, 12, 15, 18, 20]
num_bins = 3
smoothed_data = binning_smoothing(data, num_bins)
print("Original Data:", data)
print("Smoothed Data:", smoothed_data)
