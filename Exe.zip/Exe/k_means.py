import numpy as np

# Sample data (2D)
data = np.array([[1, 2], [5, 8], [1.5, 1.8], [8, 8], [1, 0.6], [9, 11]])

# Number of clusters
k = 2

# Initialize centroids randomly
centroids = data[np.random.choice(data.shape[0], k, replace=False)]

# Maximum number of iterations
max_iters = 100

for _ in range(max_iters):
    # Assign points to the nearest centroid
    labels = np.argmin(np.linalg.norm(data[:, None] - centroids, axis=2), axis=1)

    # Update centroids to the mean of assigned points
    new_centroids = np.array([data[labels == i].mean(axis=0) for i in range(k)])

    # Check for convergence (if centroids have not changed)
    if np.array_equal(new_centroids, centroids):
        break

    centroids = new_centroids

print("Cluster labels:", labels)
print("Centroids:", centroids)
