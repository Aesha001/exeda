tr=[]  #main list
li=[]  
nm=int(input("Enter the number of Transactions :"))

for i in range(nm):
       itm=int(input("Enter the number of Items :"))
       for j in range(itm):
           it=input("Enter the item name :")
           li.append(it)
       tr.append(li)
       li=[]
print(tr)

nli=[] #new list for storing unique value
for t in tr:
    for l in t:
        if(l not in nli):
            nli.append(l)
print(nli)


count = 0
fre = []  #list for store freq value
for a in nli:
    for b in tr:
        for c in b:
            if(c == a):
                count += 1
    fre.append(count)
    #print("count no",count)
    count=0
print(fre)








