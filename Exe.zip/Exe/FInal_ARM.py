tran=[]
l1=[]
n=input("Enter no of transaction-")
n=int(n)
print(n)
 
for i in range(n):
    t1=int(input("Enter no of input you want in particular transaction-"))
    for j in range(t1):
        s1=input("Enter name of item-")
        l1.append(s1)
    tran.append(l1)
    l1=[]
print(tran)
itemlist=[]
for i in tran:
    for j in i:
        if(j not in itemlist):
            itemlist.append(j)
print(itemlist)
c1=0
thresold=[]
for i in itemlist:
    for j in tran:
        for k in j:
            if(k==i):
                c1=c1+1
    thresold.append(c1)
    c1=0
print(thresold)
i=0
c2=[]
while(i<len(itemlist)):
    if(thresold[i]>1):
        c2.append(itemlist[i])
    i=i+1
print(c2)
 
i=0
c3=[]
temp=[]
while(i<len(c2)):
    j=i+1
    while(j<len(c2)):
        temp.append(c2[i])
        temp.append(c2[j])
        j=j+1
        c3.append(temp)
        temp=[]
    i=i+1
print(c3)
count=0
l3=[]
for i in c3:
    i1=i[0]
    i2=i[1]
    for j in tran:
        if((i1 in j) and (i2 in j)):
            count=count+1
    l3.append(count)
    count=0
print(l3)
final=[]
i=0
while(i<len(c3)):
    if(l3[i]>1):
        final.append(c3[i])
    i=i+1
print(final)
