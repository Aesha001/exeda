# Input data and number of bins
data = [1, 2, 3, 7, 8, 9, 12, 15, 18, 20]
num_bins = 3

# Calculate bin width
min_val = min(data)
max_val = max(data)
bin_width = (max_val - min_val) / num_bins

# Initialize bins and smoothed data lists
bins = [[] for _ in range(num_bins)]
smoothed_data = []

# Assign data points to bins
for value in data:
    bin_index = int((value - min_val) // bin_width)
    if bin_index == num_bins:
        bin_index -= 1
    bins[bin_index].append(value)

# Smooth the data within each bin by bin median
for bin_values in bins:
    if bin_values:
        bin_values.sort()
        mid = len(bin_values) // 2
        if len(bin_values) % 2 == 0:
            bin_median = (bin_values[mid - 1] + bin_values[mid]) / 2
        else:
            bin_median = bin_values[mid]
        smoothed_data.extend([bin_median] * len(bin_values))

# Print smoothed data by bin median
print("Smoothed Data by Median:", smoothed_data)
