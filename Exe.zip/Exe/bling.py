list = []
n = int(input("how many elements you want: "))

if n <= 0:
    print("Please enter a positive number of elements.")
else:
    for i in range(n):
        r = int(input("enter your element: "))
        list.append(r)
    
    list.sort()
    min_val = list[0]
    max_val = list[-1]

    if min_val == max_val:
        bing = 1
    else:
        bing = int((max_val - min_val) / len(list))

    mainlist = []
    num_item = int(len(list) / bing)

    start_index = 0
    last_index = num_item

    for j in range(bing):
        l1 = list[start_index:last_index]
        mainlist.append(l1)
        start_index = start_index + 2
        last_index = last_index + 2

    print(mainlist)
    meanlist = []

    for q in mainlist:
        sum_val = 0
        for w in q:
            sum_val = sum_val + w
        mean = int(sum_val / len(q))
        meanlist.append(mean)

    for x in range(0, len(mainlist)):
        change_val = meanlist[x]
        for y in range(0, len(mainlist[x])):
            mainlist[x][y] = change_val

    print(mainlist)
    print(meanlist)
